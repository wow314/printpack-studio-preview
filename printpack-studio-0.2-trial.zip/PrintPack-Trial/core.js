/* PrintPack Studio — original application logic. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PrintPack=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const PRESETS=[
    {id:'2x3',label:'2:3',w:8,h:12,caption:'8 × 12 in'},
    {id:'3x4',label:'3:4',w:9,h:12,caption:'9 × 12 in'},
    {id:'4x5',label:'4:5',w:8,h:10,caption:'8 × 10 in'},
    {id:'11x14',label:'11:14',w:11,h:14,caption:'11 × 14 in'},
    {id:'square',label:'Square',w:12,h:12,caption:'12 × 12 in'},
    {id:'a4',label:'A4',w:210/25.4,h:297/25.4,caption:'210 × 297 mm'}
  ];
  function plan(sw,sh,preset,{mode='fit',dpi=300,landscape=false,focusX=.5,focusY=.5}={}){
    if(![sw,sh,preset.w,preset.h,dpi].every(n=>Number.isFinite(n)&&n>0))throw Error('Invalid image or print dimensions');
    if(!['fit','fill'].includes(mode))throw Error('Invalid fitting mode');
    const iw=landscape?preset.h:preset.w,ih=landscape?preset.w:preset.h;
    const tw=Math.round(iw*dpi),th=Math.round(ih*dpi);
    const requestedScale=mode==='fill'?Math.max(tw/sw,th/sh):Math.min(tw/sw,th/sh);
    const reduction=Math.min(1,1/requestedScale);
    const width=Math.max(1,Math.floor(tw*reduction)),height=Math.max(1,Math.floor(th*reduction));
    const scale=Math.min(1,mode==='fill'?Math.max(width/sw,height/sh):Math.min(width/sw,height/sh));
    const dw=sw*scale,dh=sh*scale;
    const fx=Math.max(0,Math.min(1,Number.isFinite(focusX)?focusX:.5));
    const fy=Math.max(0,Math.min(1,Number.isFinite(focusY)?focusY:.5));
    return {width,height,dx:(width-dw)*(mode==='fill'?fx:.5),dy:(height-dh)*(mode==='fill'?fy:.5),dw,dh,scale,iw,ih,
      ppi:Math.min(width/iw,height/ih),lowRes:reduction<.999,crop:mode==='fill'?Math.max(0,1-width*height/(dw*dh)):0};
  }
  function slug(name){let s=name.replace(/\.[^.]+$/,'').normalize('NFKC').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60)||'artwork';if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(s))s='art-'+s;return s;}
  function uniqueName(name,used){const base=slug(name);let s=base,i=2;while(used.has(s.toLowerCase()))s=`${base}-${i++}`;used.add(s.toLowerCase());return s;}
  function withDpi(bytes,x,y){
    if(bytes[0]!==255||bytes[1]!==216)throw Error('Expected JPEG output');
    const dx=Math.max(1,Math.min(65535,Math.round(x))),dy=Math.max(1,Math.min(65535,Math.round(y)));
    const out=bytes.slice();let p=2;
    while(p+4<out.length&&out[p]===255){const marker=out[p+1];if(marker===218||marker===217)break;const len=(out[p+2]<<8)|out[p+3];if(len<2||p+len+2>out.length)break;
      if(marker===224&&len>=16&&out[p+4]===74&&out[p+5]===70&&out[p+6]===73&&out[p+7]===70&&out[p+8]===0){out[p+11]=1;out[p+12]=dx>>8;out[p+13]=dx&255;out[p+14]=dy>>8;out[p+15]=dy&255;return out;}p+=len+2;}
    const app0=new Uint8Array([255,224,0,16,74,70,73,70,0,1,1,1,dx>>8,dx&255,dy>>8,dy&255,0,0]);
    const result=new Uint8Array(bytes.length+app0.length);result.set(bytes.slice(0,2));result.set(app0,2);result.set(bytes.slice(2),20);return result;
  }
  // Stored ZIP bound: local header + central header + two copies of UTF-8 name; margin covers extra fields.
  function partition(entries,max=19_000_000){const groups=[];let batch=[],size=22;for(const e of entries){const cost=e.data.length+160+new TextEncoder().encode(e.name).length*2;if(cost+22>max)throw Error(`${e.name} is too large for a 19 MB ZIP. Try 150 PPI.`);if(size+cost>max){groups.push(batch);batch=[];size=22;}batch.push(e);size+=cost;}if(batch.length)groups.push(batch);return groups;}
  function customSize(w,h,unit,id){
    const factor={in:1,cm:1/2.54,mm:1/25.4}[unit],iw=Number(w)*factor,ih=Number(h)*factor;
    if(![iw,ih].every(n=>Number.isFinite(n)&&n>=.5&&n<=40))throw Error('Print dimensions must be between 0.5 and 40 inches.');
    return {id,label:`${Number(w)} × ${Number(h)} ${unit}`,caption:'Custom size',w:iw,h:ih,custom:true};
  }
  function outputOptions(art,preset,defaults){return {...defaults,focusX:.5,focusY:.5,...(art.edits?.[preset.id]||{})};}
  function deliveryCheck(parts){
    if(!parts.length)throw Error('The delivery bundle is empty.');
    if(parts.length>5)throw Error(`This listing needs ${parts.length} ZIP files; the limit is 5. Select fewer sizes or remove artworks to create a separate listing. No files have been released.`);
    for(const p of parts){if(p.bytes>=19_000_000)throw Error('A ZIP exceeds the 19 MB safety limit.');if(!/^[a-zA-Z0-9_.-]{1,70}$/.test(p.name))throw Error('A ZIP filename exceeds the delivery naming limits.');}
    return true;
  }
  return {PRESETS,plan,slug,uniqueName,withDpi,partition,customSize,outputOptions,deliveryCheck};
});
