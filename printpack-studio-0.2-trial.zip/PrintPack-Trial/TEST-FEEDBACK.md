# PrintPack trial feedback

Please answer only what you are comfortable sharing. No shop login, customer data, original artwork or payment information is needed. You may stop at any time.

## Before trying it

1. Do you currently sell printable artwork, prepare it for clients, or only plan to start?
2. Think of the last real artwork you packaged: which tools did you use, which sizes did you produce, and roughly how long did it take?
3. How often did you do this in the last four weeks? Which step, if any, caused repeated work or mistakes?

## The task

Try the included samples first. Then, if useful, prepare one of your own finished artworks with the same sizes you normally deliver. Start timing when you begin preparing the files; stop when you have checked the downloaded bundle. Include time spent fixing problems. You do not need to publish a listing.

## After trying it

- Browser and operating system:
- Could you open the extracted tool? If not, where did it stop?
- Did you use the sample or your own real workflow?
- Paper sizes and number of artworks:
- Minutes spent, including corrections:
- Did you need help? What help?
- Did you download and inspect all files? Were they usable for your normal delivery?
- Any wrong crop, missing file, confusing resolution, naming issue or unexpected behavior?
- What would you continue using instead, and why?
- Which missing capability would actually prevent you using this again?

## Optional pricing question — only after the task

If this exact workflow were reliable for your use, how would you choose between your current method and buying this tool once for US$19? Please explain your choice, including any conditions. “I would use a free alternative” and “I would not buy” are useful answers.

This is a research question, not a checkout, reservation or request for a commitment. There is no payment link. A stated preference is not counted as a sale.

Would you like one follow-up when your specific issue is fixed? Yes / No. If no, we will not follow up. Please do not include personal information in public screenshots.
